package br.com.safra.testetransacaosafra;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import br.com.setis.safra.integracaosafra.BuildConfig;
import br.com.setis.safra.integracaosafra.Gerenciador;
import br.com.setis.safra.integracaosafra.PrinterIntegracao;
import br.com.setis.safra.integracaosafra.entidades.DadosAutomacao;
import br.com.setis.safra.integracaosafra.entidades.EntradaTransacao;
import br.com.setis.safra.integracaosafra.entidades.MifareBlockData;
import br.com.setis.safra.integracaosafra.entidades.NFCRequest;
import br.com.setis.safra.integracaosafra.entidades.Operacoes;
import br.com.setis.safra.integracaosafra.entidades.RequestApi;
import br.com.setis.safra.integracaosafra.entidades.SaidaTransacao;
import br.com.setis.safra.integracaosafra.listeners.MifareNFCCallback;
import br.com.setis.safra.integracaosafra.listeners.PrinterListener;
import br.com.setis.safra.integracaosafra.listeners.TransacaoListenerCallback;
import br.com.setis.safra.integracaosafra.printer.PrinterStatus;
import br.com.setis.safra.integracaosafra.printer.PrinterTextAlignment;
import br.com.setis.safra.integracaosafra.printer.PrinterTextSize;
import br.com.setis.safra.integracaosafra.printer.PrinterTextStyle;
import br.com.setis.safra.integracaosafra.util.ReturnCodes;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private Gerenciador gerenciadorIntegracaoSafra;
    private final TransacaoListenerCallback callbackTransacaoIntegracao = new TransacaoListenerCallback() {
        @Override
        public void transacaoFinalizada(final SaidaTransacao saidaTransacao) {
            Log.d(TAG, "processaSaidaTransacao! callback recebido");

            final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            LinearLayout dialogLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.dialog_transacao, null);
            TextView comprovante = (TextView) dialogLayout.findViewById(R.id.comprovante);

            //1 = aprovada // 3 = estornada
            if (saidaTransacao.obtemResultadoTransacao() == ReturnCodes.RESULT_APROVADA
                    || (saidaTransacao.obtemOperacaoRealizada() == Operacoes.CANCELAMENTO
                    || saidaTransacao.obtemOperacaoRealizada() == Operacoes.CANCELAMENTO_VIA_NSU
                    && saidaTransacao.obtemResultadoTransacao() == ReturnCodes.RESULT_ESTORNADA)) {
                comprovante.setText(saidaTransacao.obtemComprovanteViaLojista().toString());
                builder.setView(dialogLayout);
            } else if (saidaTransacao.obtemOperacaoRealizada() == Operacoes.REIMPRESSAO
                    && saidaTransacao.obtemResultadoTransacao() == ReturnCodes.RESULT_OK) {
                builder.setMessage("Sucesso " + saidaTransacao.obtemOperacaoRealizada().name());
            } else {
                builder.setMessage("erro ao realizar " + saidaTransacao.obtemOperacaoRealizada().name());
            }

            Dialog dialogComprovante = builder.create();
            dialogComprovante.show();
        }

        @Override
        public void transacaoException(Exception e) {
            Log.e(TAG, "transacaoException: ", e);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DadosAutomacao dadosAutomacao = new DadosAutomacao("Empresa", "Automacao", "1.0");
        gerenciadorIntegracaoSafra = new Gerenciador(this, dadosAutomacao);

        //parametro true = solicita que o aviso seja exibido, false = cancela a solicitacao (nao exibe aviso)
        //gerenciador.requestExclusiveSale(true);

        TextView tVversion = findViewById(R.id.tv_version);
        tVversion.setText(getString(R.string.versao, BuildConfig.VERSION_NAME));

        Button btnExecutar = findViewById(R.id.executar);
        Spinner spinnerOperacao = findViewById(R.id.spinner_operacao);

        AtomicInteger selectedPosition = new AtomicInteger(-1);
        List<String> operacoes = new ArrayList<>();
        operacoes.add("Venda crédito");
        operacoes.add("Venda QR Code");
        operacoes.add("Venda débito");
        operacoes.add("Venda Voucher");
        operacoes.add("Venda Pré-Autorização");
        operacoes.add("Cancelamento de venda");
        operacoes.add("Reimpressão de comprovantes");
        operacoes.add("Devolução PIX");
        operacoes.add("Impressão livre");
        operacoes.add("Retentar impressão após erro");
        operacoes.add("Ler cartão NFC");
        operacoes.add("Escrever no cartão NFC");
        operacoes.add("Limpar Buffer Impressão");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.element_operacao, R.id.tv_item, operacoes);

        spinnerOperacao.setAdapter(adapter);
        spinnerOperacao.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                btnExecutar.setEnabled(true);
                selectedPosition.set(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                btnExecutar.setEnabled(false);
            }
        });

        btnExecutar.setOnClickListener((v) -> {
            switch (selectedPosition.get()) {
                case 0:
                    vendaCredito();
                    break;
                case 1:
                    vendaQrcode();
                    break;
                case 2:
                    vendaDebito();
                    break;
                case 3:
                    vendaVoucher();
                    break;
                case 4:
                    vendaPreAuto();
                    break;
                case 5:
                    cancelamento();
                    break;
                case 6:
                    reimpressaoComprovantes();
                    break;
                case 7:
                    devolucaoPix();
                    break;
                case 8:
                    impressaoLivre();
                    break;
                case 9:
                    retentarImpressaoAposErro();
                    break;
                case 10:
                    lerNFC();
                    break;
                case 11:
                    escreverNFC();
                    break;
                case 12:
                    limparBufferImpressao();
                    break;
            }
        });
    }

    private Bitmap getLogoBitmap() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inDensity = DisplayMetrics.DENSITY_XXHIGH; //redimensiona a densidade para a imagem aparecer mais compacta
        return BitmapFactory.decodeResource(getResources(), R.drawable.logo_bsf, options);
    }

    private void enviaTransacao(final RequestApi requestApi) {
        gerenciadorIntegracaoSafra.realizaTransacao(requestApi, callbackTransacaoIntegracao);
    }

    private void vendaCredito() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(100, Operacoes.VENDA_CREDITO, "01222");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void vendaQrcode() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(500, Operacoes.VENDA_QRCODE, "011111");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void vendaDebito() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(100, Operacoes.VENDA_DEBITO, "0222222");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void vendaVoucher() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(4000, Operacoes.VENDA_VOUCHER, "12345");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void vendaPreAuto() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(100, Operacoes.PRE_AUTORIZACAO, "123456");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void reimpressaoComprovantes() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(Operacoes.REIMPRESSAO, "teste");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void cancelamento() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(Operacoes.CANCELAMENTO, "01");
        //exemplo de entrada para cancelamento via nsu:
//                EntradaTransacao entradaTransacao = new EntradaTransacao("020005179576", Operacoes.CANCELAMENTO_VIA_NSU, "01");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void devolucaoPix() {
        EntradaTransacao entradaTransacao = new EntradaTransacao(Operacoes.DEVOLUCAO_PIX, "teste");
        RequestApi requestApi = new RequestApi(entradaTransacao);
        enviaTransacao(requestApi);
    }

    private void impressaoLivre() {
        final PrinterIntegracao printerIntegracao = gerenciadorIntegracaoSafra.getPrinterIntegracao();

        Bitmap bitmap = getLogoBitmap();
        printerIntegracao.addBitmap(bitmap, PrinterTextAlignment.LEFT);
        printerIntegracao.addBitmap(bitmap, PrinterTextAlignment.CENTER);
        printerIntegracao.addBitmap(bitmap, PrinterTextAlignment.RIGHT);

        printerIntegracao.addStringLine("EXTRA_SMALL_NORMAL_12345678901234567890123456789", PrinterTextSize.EXTRA_SMALL, PrinterTextStyle.NORMAL, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("EXTRA_SMALL_BOLD_1234567890123456789012345678901", PrinterTextSize.EXTRA_SMALL, PrinterTextStyle.BOLD, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("SMALL_NORMAL_12345678901234567890123456789", PrinterTextSize.SMALL, PrinterTextStyle.NORMAL, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("SMALL_BOLD_1234567890123456789012345678901", PrinterTextSize.SMALL, PrinterTextStyle.BOLD, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("MEDIUM_NORMAL_123456789012345678901234", PrinterTextSize.MEDIUM, PrinterTextStyle.NORMAL, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("MEDIUM_BOLD_12345678901234567890123456", PrinterTextSize.MEDIUM, PrinterTextStyle.BOLD, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("LARGE_NORMAL_1234567890123456789", PrinterTextSize.LARGE, PrinterTextStyle.NORMAL, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("LARGE_BOLD_123456789012345678901", PrinterTextSize.LARGE, PrinterTextStyle.BOLD, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("EXTRALARGE_NORMAL_12", PrinterTextSize.EXTRA_LARGE, PrinterTextStyle.NORMAL, PrinterTextAlignment.CENTER, false);
        printerIntegracao.addStringLine("EXTRALARGE_BOLD_1234", PrinterTextSize.EXTRA_LARGE, PrinterTextStyle.BOLD, PrinterTextAlignment.CENTER, false);

        printerIntegracao.addStringLine("MEDIUM_INVERTED", PrinterTextSize.MEDIUM, PrinterTextStyle.NORMAL, PrinterTextAlignment.CENTER, true);

        //Cria a fonte customizada. Trocar para qualquer .ttf que o usuário desejar
        Typeface customTypeface = Typeface.createFromAsset(MainActivity.this.getAssets(), "MajorMonoDisplay-Regular.ttf");
        printerIntegracao.addStringLine("FONTE PERSONALIZADA", customTypeface, 32, PrinterTextAlignment.CENTER, false);

        printerIntegracao.print(new PrinterListener() {
            @Override
            public void eventoSaida(PrinterStatus printerStatus) {
                Log.d(TAG, "Evento saida printer: " + printerStatus);

                if (printerStatus == PrinterStatus.ERROR_NO_PAPER) {
                    //tratar => PrinterStatus.ERROR_NO_PAPER
                    //exibir mensagem de erro sem papel, e quando necessario chamar printerIntegracao.print novamente.
                    // Não é necessario addLine novamente, pois o comprovante atual está no buffer, não é necessário criá-lo novamente
                    Toast.makeText(MainActivity.this, "Sem papel na impressora!\n Chamar 'reimprimir após erro'", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void eventoException(Exception e) {
                Log.e(TAG, "Exception ", e);
            }
        }, 150);
    }

    private void retentarImpressaoAposErro() {
        final PrinterIntegracao printerIntegracao = gerenciadorIntegracaoSafra.getPrinterIntegracao();
        printerIntegracao.print(new PrinterListener() {
            @Override
            public void eventoSaida(PrinterStatus printerStatus) {
                Log.d(TAG, "Evento saida printer: " + printerStatus);
            }

            @Override
            public void eventoException(Exception e) {
                Log.e(TAG, "Exception ", e);
            }
        }, 150);
    }

    private void lerNFC() {
        List<MifareBlockData> listBlocks = new ArrayList<>();
        for(int i = 0; i< 16; i++) {
            listBlocks.add(new MifareBlockData(i, Utils.hexStringToByteArray("FFFFFFFFFFFF"), null));
        }
        NFCRequest nfcRequest = new NFCRequest("Por favor aproxime o cartão no terminal", listBlocks);

        gerenciadorIntegracaoSafra.readMifareNFCBlocks(nfcRequest, new MifareNFCCallback() {
            @Override
            public void onSuccess(List<MifareBlockData> list) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Cartão lido com sucesso", Toast.LENGTH_LONG).show());
                for (MifareBlockData block : list) {
                    Log.d(TAG, String.format("NFC block : %02d - Data: %s", block.getBlockNumber(), Utils.bytesToHex(block.getData())));
                }
            }

            @Override
            public void onError(int i) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Erro ao ler o cartão", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void escreverNFC() {
        List<MifareBlockData> listBlocks = new ArrayList<>();
        listBlocks.add(new MifareBlockData(1, Utils.hexStringToByteArray("FFFFFFFFFFFF"), Utils.hexStringToByteArray("000000000000000CAFE0000000000000")));

        NFCRequest nfcRequest = new NFCRequest("Por favor aproxime o cartão no terminal", listBlocks);
        gerenciadorIntegracaoSafra.writeMifareNFCBlocks(nfcRequest, new MifareNFCCallback() {
            @Override
            public void onSuccess(List<MifareBlockData> list) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Cartão escrito com sucesso", Toast.LENGTH_LONG).show());
            }

            @Override
            public void onError(int i) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Erro ao escrever no cartão", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void limparBufferImpressao() {
        gerenciadorIntegracaoSafra.getPrinterIntegracao().clearBuffer(new PrinterListener() {
            @Override
            public void eventoSaida(PrinterStatus printerStatus) {
                if(printerStatus == PrinterStatus.OK) {
                    Toast.makeText(MainActivity.this, "Buffer impressão limpo", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void eventoException(Exception e) {
                Log.e(TAG, "eventoException: ", e);
            }
        });
    }
}
